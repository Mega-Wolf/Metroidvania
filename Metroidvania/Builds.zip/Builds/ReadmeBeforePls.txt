Dies ist wie der Name bereits sagt, nur ein Prototyp, um die grundlegenden Funktionen darzustellen und zu analysieren

Einige Bugs sind bekannt (vor allem in Verbindung mit dem Raycast Mover); es gab allerdings noch keine Zeit diese zu beheben
Auch in Verbindung mit den Monstern gibt es noch einige Probleme, was vor allem an einem schlechten Codeger�st liegt, welches mit allerdings nicht mehr gereicht h�tte rechtzeitig umzubauen


Steuerung
- Pfeiltasten links/rechts: Bewegen
- Leertaste: Springen
- X: Schlag (ggf. + hoch/runter)
- A: Heilen

- Strg: FastForward
- Shift: Ultra FastForward

Der obere Balken unterhalb des Charakters ist ein Energiebalken, der sich beim Besiegen von Monstern f�llt und f�rs Heilen verwendet werden kann.

Die Bossregion ist nicht sonderlich getestet und war haups�chlich gedacht um zu testen was denn wie einfach umsetzbar ist (die Region wird noch umgebaut; die anderen beiden Bosse werden einfacher)

Auch gibt es noch kein GameOver/Tod etc., was aufgrund der schlecht eingestellten Werte auch ziemlich sinnvoll ist.
(Dar�ber hinaus passiert auch nichts tolles, wenn man den Bossgegner besiegt hat)




Visuelles Feedback fehlt auch noch; so bekommt man noch nicht mit, wenn jemand getroffen wurde
Auch fehlt ein Hinweis, wenn ein Monster vom normalen Lauf, etwas schneller wird (hier wird noch ein kleines Ausrufezeichen etc. eingef�gt)
